<?php 
class M_team extends CI_Model{

	function get_all_team(){
		$hsl=$this->db->query("SELECT * FROM tbl_team");
		return $hsl;
	}

	function simpan_team($nip,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$mapel,$photo){
		$hsl=$this->db->query("INSERT INTO tbl_team (team_nip,team_nama,team_jenkel,team_tmp_lahir,team_tgl_lahir,team_mapel,team_photo) VALUES ('$nip','$nama','$jenkel','$tmp_lahir','$tgl_lahir','$mapel','$photo')");
		return $hsl;
	}
	function simpan_team_tanpa_img($nip,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$mapel){
		$hsl=$this->db->query("INSERT INTO tbl_team (team_nip,team_nama,team_jenkel,team_tmp_lahir,team_tgl_lahir,team_mapel) VALUES ('$nip','$nama','$jenkel','$tmp_lahir','$tgl_lahir','$mapel')");
		return $hsl;
	}

	function update_team($kode,$nip,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$mapel,$photo){
		$hsl=$this->db->query("UPDATE tbl_team SET team_nip='$nip',team_nama='$nama',team_jenkel='$jenkel',team_tmp_lahir='$tmp_lahir',team_tgl_lahir='$tgl_lahir',team_mapel='$mapel',team_photo='$photo' WHERE team_id='$kode'");
		return $hsl;
	}
	function update_team_tanpa_img($kode,$nip,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$mapel){
		$hsl=$this->db->query("UPDATE tbl_team SET team_nip='$nip',team_nama='$nama',team_jenkel='$jenkel',team_tmp_lahir='$tmp_lahir',team_tgl_lahir='$tgl_lahir',team_mapel='$mapel' WHERE team_id='$kode'");
		return $hsl;
	}
	function hapus_team($kode){
		$hsl=$this->db->query("DELETE FROM tbl_team WHERE team_id='$kode'");
		return $hsl;
	}

	//front-end
	function team(){
		$hsl=$this->db->query("SELECT * FROM tbl_team");
		return $hsl;
	}
	function team_perpage($offset,$limit){
		$hsl=$this->db->query("SELECT * FROM tbl_team limit $offset,$limit");
		return $hsl;
	}

}