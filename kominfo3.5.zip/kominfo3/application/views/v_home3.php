<!DOCTYPE html>
<html  >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.4, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="<?php echo base_url().'kominfo4/assets/images/mylogo-128x127-1.png'?>" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Home</title>
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/material-design/css/material-icons.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/themify/css/themify-icons.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/web/assets/mobirise-icons2/mobirise2.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/tether/tether.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-grid.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-reboot.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/animatecss/animate.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/socicon/css/styles.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/dropdown/css/style.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/theme/css/style.css'?>">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>"><link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>" type="text/css">
  
  <?php
            error_reporting(0);
            function limit_words($string, $word_limit){
                $words = explode(" ",$string);
                return implode(" ",array_splice($words,0,$word_limit));
            }

        ?>
  
  
</head>
<body>
  
<?php 
    $this->load->view('v_navbar');
  ?>

<section class="slider2 cid-syvtilLecH" id="slider2-1e">
    

    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-12">
                <div class="carousel slide carousel-fade" id="syvwqAo3yP" data-ride="carousel" data-interval="8000">
                    
                    <ol class="carousel-indicators">
                        <li data-slide-to="0" class="active" data-target="#syvwqAo3yP"></li>
                        <li data-slide-to="1" data-target="#syvwqAo3yP"></li>
                        
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item slider-image item active">
                            <div class="item-wrapper">
                                <img class="d-block w-100" src="<?php echo base_url().'kominfo4/assets/images/diskominfo-1387x600.jpg'?>">
                                <div class="carousel-caption d-none d-md-block">
                                    <h5 class="mbr-section-subtitle mbr-fonts-style display-5">
                                        <strong>Fixed-Height Slider</strong>
                                    </h5>
                                    <p class="mbr-section-text mbr-fonts-style display-7">
                                        Click on the image to edit slides.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="carousel-item slider-image item">
                            <div class="item-wrapper">
                                <img class="d-block w-100" src="<?php echo base_url().'kominfo4/assets/images/sliderbaru-1387x600.png'?>">
                                <div class="carousel-caption d-none d-md-block">
                                    <h5 class="mbr-section-subtitle mbr-fonts-style display-5">
                                        <strong>Fixed-Height Slider</strong>
                                    </h5>
                                    <p class="mbr-section-text mbr-fonts-style display-7">
                                        Click on the image to edit slides.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control carousel-control-prev" role="button" data-slide="prev" href="#syvwqAo3yP">
                        <span class="mobi-mbri mobi-mbri-arrow-prev" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control carousel-control-next" role="button" data-slide="next" href="#syvwqAo3yP">
                        <span class="mobi-mbri mobi-mbri-arrow-next" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="features1 cid-sy1VGyxaHS" id="features2-l">

    

    
    <div class="container">
        <div class="row justify-content-center">
        
            <div class="col-12 col-md-6 col-lg-3">
            <a href="<?php echo base_url().'artikel'?>">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <span class="mbr-iconfont ti-book"></span>
                        <h4 class="card-title align-center mbr-black mbr-fonts-style display-7">
                            <strong>Berita</strong><strong><br></strong></h4>
                    </div>
                </div>
            </a>
            </div>
            <div class="col-10 col-md-6 col-lg-3">
                <div class="card-wrapper">
                <a href="<?php echo base_url().'galeri'?>">
                    <div class="card-box align-center">
                        <span class="mbr-iconfont ti-gallery"></span>
                        <h4 class="card-title align-center mbr-black mbr-fonts-style display-7">
                            <strong>Galleri&nbsp;</strong><strong>Kegiatan</strong></h4>
                    </div>
                </a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                    <a href="<?php echo base_url().'kontak'?>">
                        <span class="mbr-iconfont material-call material"></span>
                        <h4 class="card-title align-center mbr-black mbr-fonts-style display-7">
                            <strong>Kontak</strong></h4>
                    </a>
                    </div>
                
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <span class="mbr-iconfont mobi-mbri-map-pin mobi-mbri"></span>
                        <h4 class="card-title align-center mbr-black mbr-fonts-style display-7">MAP</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="testimonials1 cid-sy22ZFO2pG" id="testimonials1-o">
    

    
    <div class="container">
        <h3 class="mbr-section-title mbr-fonts-style align-center mb-4 display-2">
            <strong>SAMBUTAN KEPALA DINAS</strong></h3>
        <div class="row align-items-center">
            <div class="col-12 col-md-4">
                <div class="image-wrapper">
                    <img src="<?php echo base_url().'kominfo4/assets/images/pjjamal-850x1216.png'?>" alt="Mobirise">
                </div>
            </div>
            <div class="col-12 col-md">
                <div class="text-wrapper">
                    <p class="mbr-text mbr-fonts-style mb-4 display-7">Pada kesempatan ini marilah kita ucapkan puji syukur kehadirat Allah SWT, karena atas rahmat dan karuniaNYA kita telah dapat membangun, mengembangkan dan mengelola website Dinas Komunikasi dan Informatika Kabupaten Siak. Dengan adanya website ini diharapkan masyarakat dapat mengetahui informasi mengenai kegiatan yang dilakukan oleh Dinas Komunikasi dan Informatika Kabupaten Siak. Untuk menyempurnakan Website ini masyarakat dapat menyampaikan melalui Kontak Personal maupun kolom komentar yang ada pada website ini.</p>
                    <p class="name mbr-fonts-style mb-1 display-4"><strong>Drs. H. Jamaluddin M.Si</strong></p>
                    <p class="position mbr-fonts-style display-4">
                        <strong>Kepala Dinas</strong></p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="features3 cid-sy22BtZtUF" id="features3-n">
    
    
    <div class="container">
        <div class="mbr-section-head">
            <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                <strong>Berita</strong></h4>
            
        </div>
        <div class="row mt-4">
        <?php
				foreach ($post->result_array() as $j) :
					$post_id=$j['tulisan_id'];
					$post_judul=$j['tulisan_judul'];
					$post_isi=$j['tulisan_isi'];
					$post_author=$j['tulisan_author'];
					$post_image=$j['tulisan_gambar'];
					$post_tglpost=$j['tanggal'];
					$post_slug=$j['tulisan_slug'];
			?>
            <div class="item features-image сol-12 col-md-6 col-lg-4">
            <a class="fh5co-entry" href="<?php echo base_url().'artikel/'.$post_slug;?>">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="<?php echo base_url().'assets/images/'.$post_image;?>">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong><?php echo $post_judul;?></strong></h5>
                        <span class="fh5co-date"><?php echo $post_tglpost.' | '.$post_author;?></span>
                        <p class="mbr-text mbr-fonts-style mt-3 display-7"><?php echo limit_words($post_isi,20).'...';?>.</p>
                    </div>
                    
                </div>
            </a>
            </div><?php endforeach;?>
        </div>
    </div>
</section>
<center><div class="mbr-section-btn item-footer mt-2"><a href="<?php echo base_url().'artikel'?>" class="btn btn-primary item-btn display-7" target="_blank">Learn More
                            &gt;</a></div></center>
<section class="map1 cid-sy233rhHrc" id="map1-p">
    
    
    <div class="container">
        <div class="mbr-section-head mb-4">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                <strong>Map</strong>
            </h3>
            
        </div>
        <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.427381610198!2d102.01855381416046!3d0.8020823633153241!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d426d7542fc7f9%3A0x8008aed46c647e25!2sDiskominfo%20Siak!5e0!3m2!1sid!2sid!4v1621585858370!5m2!1sid!2sid" allowfullscreen=""></iframe></div>
    </div>
</section>

<section class="share3 cid-sy236qUVrK" id="share3-q">
    
     
    
    

    <div class="container">
        <div class="media-container-row">
            <div class="col-12">
                <h3 class="mbr-section-title align-center mb-3 mbr-fonts-style display-2">
                    <strong>Follow Us!</strong>
                </h3>
                <div class="social-list align-center">
                   
                    <a class="iconfont-wrapper bg-facebook m-2 " target="_blank" href="https://www.facebook.com/diskominfosiak">
                            <span class="socicon-facebook socicon"></span>
                        </a>
                        
                        <a class="iconfont-wrapper bg-instagram m-2" href="https://www.instagram.com/diskominfosiak/" target="_blank">
                            <span class="socicon-instagram socicon"></span>
                        </a>
                        
                        
                        
                        
                        
                        
                        
                        
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
    $this->load->view('v_footer');
  ?>
<script src="<?php echo base_url().'kominfo4/assets/web/assets/jquery/jquery.min.js'?>"></script>
  <script src="<?php echo base_url().'kominfo4/assets/popper/popper.min.js'?>"></script>
    <script src="<?php echo base_url().'kominfo4/assets/tether/tether.min.js'?>"></script>
      <script src="<?php echo base_url().'kominfo4/assets/bootstrap/js/bootstrap.min.js'?>"></script>
        <script src="<?php echo base_url().'kominfo4/assets/smoothscroll/smooth-scroll.js'?>"></script>
          <script src="<?php echo base_url().'kominfo4/assets/viewportchecker/jquery.viewportchecker.js'?>"></script>
            <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/nav-dropdown.js'?>"></script>
              <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/navbar-dropdown.js'?>"></script>
                <script src="<?php echo base_url().'kominfo4/assets/touchswipe/jquery.touch-swipe.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/theme/js/script.js'?>"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>