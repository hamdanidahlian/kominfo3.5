<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.4, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.4, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="<?php echo base_url().'kominfo4/assets/images/mylogo-128x127-1.png'?>" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Berita</title>
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/web/assets/mobirise-icons2/mobirise2.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/tether/tether.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-grid.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-reboot.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/animatecss/animate.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/dropdown/css/style.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/socicon/css/styles.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/theme/css/style.css'?>">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>"><link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>" type="text/css">
  
  <?php
            error_reporting(0);
            function limit_words($string, $word_limit){
                $words = explode(" ",$string);
                return implode(" ",array_splice($words,0,$word_limit));
            }

        ?>
  
  
</head>
<body>
  
<?php 
    $this->load->view('v_navbar');
  ?>


<section class="slider2 cid-syp5sLBQbw">
    <div class="container">
        <div class="row justify-content-center">
        
            <div class="col-20 col-md-20">
                <div class="carousel slide" data-interval="5000">
                
                    <div class="carousel-inner">
                    <?php
				foreach ($data->result_array() as $j) :
						$post_id=$j['tulisan_id'];
						$post_judul=$j['tulisan_judul'];
						$post_isi=$j['tulisan_isi'];
						$post_author=$j['tulisan_author'];
						$post_image=$j['tulisan_gambar'];
						$post_tglpost=$j['tanggal'];
						$post_slug=$j['tulisan_slug'];
				?>
                        <div class="carousel-item slider-image item active">
                        
                            <div class="item-wrapper">
                
                                <img class="d-block w-100" src="<?php echo base_url().'assets/images/'.$post_image;?>">
                                
                                <div class="carousel-caption d-none d-md-block">
                                    <h1 class="p-3 mb-2 bg-white text-dark ">
                                    <strong><b><a href="<?php echo base_url().'artikel/'.$post_slug;?>"><?php echo $post_judul;?></b></strong>
                                        
                                    </h1>
                                    
                                </div>
                            </div><?php endforeach;?>
                        </div>
                    </div>
                    
                </div>
            </div>
            </div>
        </div>
    </div>
</section>

<section class="features3 cid-syp5BZBb5U" id="features3-u">
    
    
    <div class="container">
        <div class="mbr-section-head">
            <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                <strong>Berita</strong></h4>
            
        </div>
        
        <div class="row mt-4">
        <?php
				foreach ($data->result_array() as $j) :
						$post_id=$j['tulisan_id'];
						$post_judul=$j['tulisan_judul'];
						$post_isi=$j['tulisan_isi'];
						$post_author=$j['tulisan_author'];
						$post_image=$j['tulisan_gambar'];
						$post_tglpost=$j['tanggal'];
						$post_slug=$j['tulisan_slug'];
				?>
            <div class="item features-image сol-12 col-md-6 col-lg-4">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="<?php echo base_url().'assets/images/'.$post_image;?>">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong><a href="<?php echo base_url().'artikel/'.$post_slug;?>"><?php echo $post_judul;?></a></strong></h5>
                        
                        <p class="mbr-text mbr-fonts-style mt-3 display-7"><?php echo $post_tglpost.' | '.$post_author;?></p>
                    </div>
                    <p><?php echo limit_words($post_isi,10).'...';?></em></p>
                    <div class="mbr-section-btn item-footer mt-2"><a href="<?php echo base_url().'artikel/'.$post_slug;?>" class="btn btn-primary item-btn display-7" target="_blank">Baca Selengkapnya
                            &gt;</a></div>
                </div>
            </div><?php endforeach;?>
            
        </div>
        
    </div>
</section>

<?php 
    $this->load->view('v_footer');
  ?><script src="<?php echo base_url().'kominfo4/assets/web/assets/jquery/jquery.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/popper/popper.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/tether/tether.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/bootstrap/js/bootstrap.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/smoothscroll/smooth-scroll.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/viewportchecker/jquery.viewportchecker.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/nav-dropdown.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/navbar-dropdown.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/touchswipe/jquery.touch-swipe.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/theme/js/script.js'?>"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>