<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.4, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.4, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="<?php echo base_url().'kominfo4/assets/images/mylogo-128x127-1.png'?>" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Pengumuman</title>
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/tether/tether.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-grid.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-reboot.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/animatecss/animate.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/dropdown/css/style.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/socicon/css/styles.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/theme/css/style.css'?>">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>"><link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>" type="text/css">
  
  <link rel="shorcut icon" href="<?php echo base_url().'theme/images/icon.png'?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/bootstrap.min.css'?>">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/font-awesome.min.css'?>">
    <!-- Simple Line Font -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/simple-line-icons.css'?>">
    <!-- Calendar Css -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/fullcalendar.min.css'?>" />
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/owl.carousel.min.css'?>">
    <!-- Main CSS -->
    <link href="<?php echo base_url().'theme/css/style.css'?>" rel="stylesheet">
  
  
</head>
<body>
  
<?php 
    $this->load->view('v_navbar');
  ?>

<section class="content3 cid-syvg6Xavs1" id="content3-1c">
    
    
    <div class="container">
        <div class="mbr-section-head">
            <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><strong>Pengumuman</strong></h4>
            <h5 class="mbr-section-subtitle mbr-fonts-style align-center mb-0 mt-2 display-5">Cek Pengumuman Disini</h5>
        </div>
        <div class="row mt-4"><div class="tab-pane active" id="upcoming-events" role="tabpanel">
                 
                 <div class="col-md-12"> <?php foreach($data->result() as $row):?>
                     <div class="row">
                         <div class="col-md-2">
                             <div class="event-date">
                                 <h4><?php echo date("d", strtotime($row->pengumuman_tanggal));?></h4> <span><?php echo date("M Y", strtotime($row->pengumuman_tanggal));?></span>
                             </div>
                             <span class="event-time"><?php echo date("H:i", strtotime($row->pengumuman_tanggal)).' WIB';?></span>
                         </div>
                         <div class="col-md-10">
                             <div class="event-heading">
                                 <h3><?php echo $row->pengumuman_judul;?></h3>
                                 <p><?php echo $row->pengumuman_deskripsi;?></p>
                             </div>
                       </div>
                   </div>
                   <hr class="event-underline">
               </div>
             <?php endforeach;?>
            

        </div>
    </div>
</section>

<section class="footer7 cid-syvrknHEal" once="footers" id="footer7-1d">

    
<?php 
    $this->load->view('v_footer');
  ?>
    

    <script src="<?php echo base_url().'kominfo4/assets/web/assets/jquery/jquery.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/popper/popper.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/tether/tether.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/bootstrap/js/bootstrap.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/smoothscroll/smooth-scroll.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/viewportchecker/jquery.viewportchecker.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/nav-dropdown.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/navbar-dropdown.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/touchswipe/jquery.touch-swipe.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/theme/js/script.js'?>"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>'?>