<link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/material-design/css/material-icons.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/themify/css/themify-icons.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/web/assets/mobirise-icons2/mobirise2.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/tether/tether.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-grid.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-reboot.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/animatecss/animate.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/socicon/css/styles.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/dropdown/css/style.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/theme/css/style.css'?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"></noscript>

  <link rel="preload" as="style" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>"><link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>" type="text/css">
  