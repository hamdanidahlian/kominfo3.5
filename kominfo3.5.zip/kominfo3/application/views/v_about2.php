<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.4, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.4, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="<?php echo base_url().'kominfo4/assets/images/mylogo-128x127-1.png'?>" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Tentang</title>
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/web/assets/mobirise-icons2/mobirise2.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/tether/tether.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-grid.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-reboot.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/animatecss/animate.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/dropdown/css/style.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/socicon/css/styles.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/theme/css/style.css'?>">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>"><link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>" type="text/css">
  
  
  
  
</head>
<body>
  
<?php 
    $this->load->view('v_navbar');
  ?>

<section class="header9 cid-syp6MCSIU2" id="header9-11">

    

    

    <div class="text-center container">
        <div class="row justify-content-center">
            <div class="col-md-12 col-lg-9">
                <div class="image-wrap mb-4">
                    <img src="<?php echo base_url().'kominfo4/assets/images/mylogo-128x127-1.png'?>" alt="Mobirise">
                </div>
                <h1 class="mbr-section-title mbr-fonts-style mb-3 display-2"><strong>Selamat Datang di Website Resmi Dinas Komunikasi dan Informatika Kabupaten Siak</strong></h1>
                
                
            </div>
        </div>
    </div>
</section>

<section class="features16 cid-sypzsDKcrE" id="features17-16">
    

    
    <div class="container">
        <div class="content-wrapper">
            <div class="row align-items-center">
                <div class="col-12 col-lg-4">
                    <div class="image-wrapper">
                        <img src="<?php echo base_url().'kominfo4/assets/images/pjjamal-850x1216.png'?>" alt="Mobirise">
                    </div>
                </div>
                <div class="col-12 col-lg">
                    <div class="text-wrapper">
                        
                        <p class="mbr-text mbr-fonts-style mb-4 display-4">
                            Pada kesempatan ini marilah kita ucapkan puji syukur kehadirat Allah SWT, karena atas rahmat dan karuniaNYA kita telah dapat membangun, mengembangkan dan mengelola website Dinas Komunikasi dan Informatika Kabupaten Siak. Dengan adanya website ini diharapkan masyarakat dapat mengetahui informasi mengenai kegiatan yang dilakukan oleh Dinas Komunikasi dan Informatika Kabupaten Siak. Untuk menyempurnakan Website ini masyarakat dapat menyampaikan melalui Kontak Personal maupun kolom komentar yang ada pada website ini.<br><br><strong>Drs. H. Jamaluddin M.Si</strong><br>KEPALA DISKOMINFO SIAK</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="team1 cid-sypzXNC492" id="team1-17">
    

    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <h3 class="mbr-section-title mbr-fonts-style align-center mb-4 display-2">
                    <strong>Struktur Organisasi</strong></h3>
                
            </div>
            <div class="col-sm-6 col-lg-3">
            <?php foreach ($data->result() as $row) : ?>
                    <div class="col-xs-12 col-sm-6 col-md-3">
                        <div class="admission_insruction">
                          <?php if(empty($row->team_photo)):?>
                            <img src="<?php echo base_url().'assets/images/blank.png';?>" class="img-fluid" alt="#">
                          <?php else:?>
                            <img src="<?php echo base_url().'assets/images/'.$row->team_photo;?>" class="img-fluid" alt="#">
                          <?php endif;?>
                <div class="card-wrap">
                    <div class="image-wrap">
                        <img src=>
                    </div>
                    <div class="content-wrap">
                        <h5 class="mbr-section-title card-title mbr-fonts-style align-center m-0 display-5">
                            <strong>John Smith</strong>
                        </h5>
                        <h6 class="mbr-role mbr-fonts-style align-center mb-3 display-4">
                            <strong>Programmer</strong>
                        </h6>
                        <p class="card-text mbr-fonts-style align-center display-7">
                            No special actions required, all sites you make with Mobirise are mobile-friendly.
                        </p>
                        <div class="social-row display-7">
                            <div class="soc-item">
                                <a href="https://www.facebook.com/Mobirise/" target="_blank">
                                    <span class="mbr-iconfont socicon socicon-facebook"></span>
                                </a>
                            </div>
                            <div class="soc-item">
                                <a href="https://twitter.com/mobirise" target="_blank">
                                    <span class="mbr-iconfont socicon socicon-twitter"></span>
                                </a>
                            </div>
                            <div class="soc-item">
                                <a href="https://instagram.com/mobirise" target="_blank">
                                    <span class="mbr-iconfont socicon socicon-instagram"></span>
                                </a>
                            </div>
                            
                            
                        </div>
                        
                    </div>
                </div><?php endforeach;?>
            </div>
        </div>
    </div>
</section>

<section class="contacts4 cid-sypA4YwYCT" id="contacts4-18">

    

    

    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="text-content col-12 col-md-6">
                <h2 class="mbr-section-title mbr-fonts-style display-2">
                    <strong>Follow kami</strong></h2>
                <p class="mbr-text mbr-fonts-style display-7">Dapatkan informasi yang lain dari kami dengan follow media sosial kami</p>
            </div>
            <div class="icons d-flex align-items-center col-12 col-md-6 justify-content-end mt-md-0 mt-2 flex-wrap">
                <a href="https://twitter.com/mobirise" target="_blank">
                    <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span>
                </a>
                <a href="https://www.facebook.com/pages/Mobirise/1616226671953247" target="_blank">
                    <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social"></span>
                </a>
                <a href="https://www.youtube.com/c/mobirise" target="_blank">
                    <span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social"></span>
                </a>
                
                
                
                
                
                
                
            </div>
        </div>
    </div>
    
</section>

<section class="contacts3 map1 cid-sypA7cZB9g" id="contacts3-19">

    
    
    <div class="container">
        <div class="mbr-section-head">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                <strong>Contacts</strong>
            </h3>
            <h4 class="mbr-section-subtitle mbr-fonts-style align-center mb-0 mt-2 display-5">
                Contacts Subtitle
            </h4>
        </div>
        <div class="row justify-content-center mt-4">
            <div class="card col-12 col-md-6">
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-globe mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            <strong>Phone</strong>
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">082268841111</p>
                    </div>
                </div>
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-globe mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            <strong>Email</strong>
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7"><a href="mailto:Diskominfosiak@gmail.com" class="text-primary">Diskominfosiak@gmail.com</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="map-wrapper col-12 col-md-6">
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.427381610198!2d102.01855381416046!3d0.8020823633153241!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d426d7542fc7f9%3A0x8008aed46c647e25!2sDiskominfo%20Siak!5e0!3m2!1sid!2sid!4v1621585858370!5m2!1sid!2sid" allowfullscreen=""></iframe></div>
            </div>
        </div>
    </div>
</section>

<?php 
    $this->load->view('v_footer');
  ?><script src="<?php echo base_url().'kominfo4/assets/web/assets/jquery/jquery.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/popper/popper.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/tether/tether.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/bootstrap/js/bootstrap.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/smoothscroll/smooth-scroll.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/viewportchecker/jquery.viewportchecker.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/nav-dropdown.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/navbar-dropdown.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/touchswipe/jquery.touch-swipe.min.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/sociallikes/social-likes.js'?>"></script>  <script src="<?php echo base_url().'kominfo4/assets/theme/js/script.js'?>"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>'?>