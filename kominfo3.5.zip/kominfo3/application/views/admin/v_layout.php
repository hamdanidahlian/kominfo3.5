<?php 
    $query=$this->db->query("SELECT * FROM tbl_inbox WHERE inbox_status='1'");
    $jum_pesan=$query->num_rows();
    $query1=$this->db->query("SELECT * FROM tbl_komentar WHERE komentar_status='0'");
    $jum_komentar=$query1->num_rows();
?>
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      
      <ul class="sidebar-menu">
      <?php
              $id_admin=$this->session->userdata('idadmin');
              $q=$this->db->query("SELECT * FROM tbl_pengguna WHERE pengguna_id='$id_admin'");
              $c=$q->row_array();
          ?>
          <li class="header">
                <center><img src="<?php echo base_url().'assets/images/'.$c['pengguna_photo'];?>" class="img-circle" alt="" height="50%" width="50%"></center>

                <center><br><p>
                  <h3><?php echo $c['pengguna_nama'];?></h3><br>
                  <?php if($c['pengguna_level']=='1'):?>
                    <h4>Administrator</h4>
                  <?php else:?>
                    <h4>Author</h4>
                  <?php endif;?>
                </p></center>
              </li>
        <li class="header">Menu Utama</li>
        <?php if($c['pengguna_level']=='1'):?>
        <li <?=$this->uri->segment(2)=='dashboard' || $this->uri->segment(2)=='' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/dashboard'?>">
            <i class="fa fa-home"></i> <span>Dashboardd</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li <?=$this->uri->segment(3)=='add_tulisan' || $this->uri->segment(2)=='tulisan' || $this->uri->segment(2)=='kategori' ? 'class="active"' : ''?>>
          <a href="#">
            <i class="fa fa-newspaper-o"></i>
            <span>Post</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?=$this->uri->segment(3)=='add_tulisan' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/tulisan/add_tulisan'?>"><i class="fa fa-thumb-tack"></i> Add New</a></li>
            <li <?=$this->uri->segment(2)=='tulisan' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/tulisan'?>"><i class="fa fa-list"></i> Post Lists</a></li>
            <li <?=$this->uri->segment(2)=='kategori' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i> Kategori</a></li>
          </ul>
        </li>

       

        <li <?=$this->uri->segment(2)=='pengguna' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/pengguna'?>">
            <i class="fa fa-users"></i> <span>Pengguna</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>

        <li <?=$this->uri->segment(2)=='pengumuman' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/pengumuman'?>">
            <i class="fa fa-volume-up"></i> <span>Pengumuman</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>

        <li <?=$this->uri->segment(2)=='team' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/team'?>">
            <i class="fa fa-users"></i> <span>Team</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
       
        <li <?=$this->uri->segment(2)=='album' || $this->uri->segment(2)=='galeri' ? 'class="active"' : ''?>>
          <a href="#">
            <i class="fa fa-camera"></i>
            <span>Gallery</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?=$this->uri->segment(2)=='album' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/album'?>"><i class="fa fa-clone"></i> Album</a></li>
            <li <?=$this->uri->segment(2)=='galeri' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/galeri'?>"><i class="fa fa-picture-o"></i> Photos</a></li>
          </ul>
        </li>

        <li <?=$this->uri->segment(2)=='komentar' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/komentar'?>">
            <i class="fa fa-comment"></i> <span>Komentar</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"><?php echo $jum_komentar;?></small>
            </span>
          </a>
        </li>

        
        
        <li <?=$this->uri->segment(2)=='inbox' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/inbox'?>">
            <i class="fa fa-envelope"></i> <span>Inbox</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"><?php echo $jum_pesan;?></small>
            </span>
          </a>
        </li>

         <li>
          <a href="<?php echo base_url().'administrator/logout'?>">
            <i class="fa fa-sign-out"></i> <span>Sign Out</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <?php else:?>
          <li <?=$this->uri->segment(2)=='dashboard' || $this->uri->segment(2)=='' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/dashboard'?>">
            <i class="fa fa-home"></i> <span>Dashboardd</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li <?=$this->uri->segment(3)=='add_tulisan' || $this->uri->segment(2)=='tulisan' || $this->uri->segment(2)=='kategori' ? 'class="active"' : ''?>>
          <a href="#">
            <i class="fa fa-newspaper-o"></i>
            <span>Post</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?=$this->uri->segment(3)=='add_tulisan' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/tulisan/add_tulisan'?>"><i class="fa fa-thumb-tack"></i> Add New</a></li>
            <li <?=$this->uri->segment(2)=='tulisan' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/tulisan'?>"><i class="fa fa-list"></i> Post Lists</a></li>
            <li <?=$this->uri->segment(2)=='kategori' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i> Kategori</a></li>
          </ul>
        </li>

       

        <li <?=$this->uri->segment(2)=='pengumuman' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/pengumuman'?>">
            <i class="fa fa-megaphone"></i> <span>Pengumuman</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
       
        <li <?=$this->uri->segment(2)=='album' || $this->uri->segment(2)=='galeri' ? 'class="active"' : ''?>>
          <a href="#">
            <i class="fa fa-camera"></i>
            <span>Gallery</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?=$this->uri->segment(2)=='album' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/album'?>"><i class="fa fa-clone"></i> Album</a></li>
            <li <?=$this->uri->segment(2)=='galeri' ? 'class="active"' : ''?>><a href="<?php echo base_url().'admin/galeri'?>"><i class="fa fa-picture-o"></i> Photos</a></li>
          </ul>
        </li>

        <li <?=$this->uri->segment(2)=='komentar' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/komentar'?>">
            <i class="fa fa-comment"></i> <span>Komentar</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"><?php echo $jum_komentar;?></small>
            </span>
          </a>
        </li>

        
        
        <li <?=$this->uri->segment(2)=='inbox' ? 'class="active"' : ''?>>
          <a href="<?php echo base_url().'admin/inbox'?>">
            <i class="fa fa-envelope"></i> <span>Inbox</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"><?php echo $jum_pesan;?></small>
            </span>
          </a>
        </li>

         <li>
          <a href="<?php echo base_url().'administrator/logout'?>">
            <i class="fa fa-sign-out"></i> <span>Sign Out</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li><?php endif;?>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>