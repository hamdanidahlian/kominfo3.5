<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.4, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.4, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="<?php echo base_url().'kominfo4/assets/images/mylogo-128x127-1.png" type="image/x-icon'?>">
  <meta name="description" content="">
  
  
  <title>Kontak</title>
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/web/assets/mobirise-icons2/mobirise2.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/tether/tether.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-grid.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/bootstrap/css/bootstrap-reboot.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/dropdown/css/style.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/socicon/css/styles.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/theme/css/style.css'?>">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>"><link rel="stylesheet" href="<?php echo base_url().'kominfo4/assets/mobirise/css/mbr-additional.css'?>" type="text/css">
  
  
  
  
</head>
<body>
  <!-- navbar -->
<?php 
    $this->load->view('v_navbar');
  ?>

<section class="contacts3 map1 cid-syp6ycmtvM" id="contacts3-z">

    
    
    <div class="container">
        <div class="mbr-section-head">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                <strong>Contacts</strong>
            </h3>
            <h4 class="mbr-section-subtitle mbr-fonts-style align-center mb-0 mt-2 display-5">
                Contacts Subtitle
            </h4>
        </div>
        <div class="row justify-content-center mt-4">
            <div class="card col-12 col-md-6">
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-globe mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            <strong>Phone</strong>
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            <a href="tel:+12345678910" class="text-primary">0 (800) 123 45 67</a>
                        </p>
                    </div>
                </div>
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-globe mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            <strong>Email</strong>
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            <a href="mailto:info@site.com" class="text-primary">info@site.com</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="map-wrapper col-12 col-md-6">
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.427381610198!2d102.01855381416046!3d0.8020823633153241!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d426d7542fc7f9%3A0x8008aed46c647e25!2sDiskominfo%20Siak!5e0!3m2!1sid!2sid!4v1621585858370!5m2!1sid!2sid" allowfullscreen=""></iframe></div>
            </div>
        </div>
    </div>
</section>

<section class="share3 cid-syp6DgQnkg" id="share3-10">
    
     
    
    

    <div class="container">
        <div class="media-container-row">
            <div class="col-12">
                <h3 class="mbr-section-title align-center mb-3 mbr-fonts-style display-2">
                    <strong>Follow Us!</strong>
                </h3>
                <div class="social-list align-center">
                   
                    <a class="iconfont-wrapper bg-facebook m-2 " target="_blank" href="https://mobiri.se">
                            <span class="socicon-facebook socicon"></span>
                        </a>
                        <a class="iconfont-wrapper bg-twitter m-2" href="https://mobiri.se" target="_blank">
                            <span class="socicon-twitter socicon"></span>
                        </a>
                        <a class="iconfont-wrapper bg-instagram m-2" href="https://mobiri.se" target="_blank">
                            <span class="socicon-instagram socicon"></span>
                        </a>
                        
                        
                        
                        
                        
                        
                        
                        
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
    $this->load->view('v_footer');
  ?><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;">
  <a href="https://mobirise.site/e" ></a>
  
  <a href="https://mobirise.site/y" style="color:#aaa;"></a>
  </section>
    <script src="<?php echo base_url().'kominfo4/assets/web/assets/jquery/jquery.min.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/popper/popper.min.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/tether/tether.min.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/bootstrap/js/bootstrap.min.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/smoothscroll/smooth-scroll.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/nav-dropdown.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/dropdown/js/navbar-dropdown.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/touchswipe/jquery.touch-swipe.min.js'?>"></script>  
    <script src="<?php echo base_url().'kominfo4/assets/theme/js/script.js'?>"></script>  
  
  
</body>
</html>