<section class="footer7 cid-syvrknHEal" once="footers" id="footer7-1d">

    

    

    <div class="container">
        <div class="media-container-row align-center mbr-white">
            <div class="col-12">
                <p class="mbr-text mb-0 mbr-fonts-style display-7">
                   <h3> © Copyright 2021 DISKOMINFO SIAK - All Rights Reserved</h3>
                </p>
            </div>
        </div>
    </div>
</section><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;">
<a href="https://mobirise.site/e" ></a>

<a href="https://mobirise.site/y" style="color:#aaa;"></a>
</section>